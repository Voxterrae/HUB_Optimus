# HUB Optimus – Open Source Diplomacy Framework

## Overview
HUB Optimus is an open-source conceptual framework for building adaptive, ethical, and multipolar diplomacy systems.

## What's Included
- Conceptual Manifesto (EN, ES, DE)
- System Evaluation & Ethics Protocols
- Peace Verification Frameworks

## License
Creative Commons BY-SA 4.0
