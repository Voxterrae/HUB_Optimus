import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ROUTE = ROOT / "site" / "obsidian-HUB_Optimus"
VAULT = ROOT / "obsidian-HUB_Optimus"
INDEX = ROUTE / "index.html"
APP_V11 = ROUTE / "app-v11.js"
STYLES_V11 = ROUTE / "styles-v11.css"
LEARNING = ROUTE / "system.learning.json"
INVENTORY = ROUTE / "system.inventory.json"
DELTA = ROUTE / "system.delta.json"
GENERATOR = ROOT / "tools" / "project_intelligence" / "repository_intelligence.py"

BASELINE_COMMIT = "30e985226347b4bc59b0e187b96633a09647ca42"
V1_CANDIDATE = "9c7b5d81b2cf85d349b1ca141d559a75067a9b14"
ALLOWED_STATUSES = {
    "active",
    "partial",
    "experimental",
    "deprecated",
    "planned",
    "unknown",
}
ALLOWED_CONFIDENCE = {"CONFIRMED", "INFERRED", "UNKNOWN"}


def load_learning_model():
    return json.loads(LEARNING.read_text(encoding="utf-8"))


def load_inventory():
    return json.loads(INVENTORY.read_text(encoding="utf-8"))


def load_delta():
    return json.loads(DELTA.read_text(encoding="utf-8"))


def test_v11_assets_are_additive_and_referenced():
    index = INDEX.read_text(encoding="utf-8")
    assert './styles-v11.css' in index
    assert './app-v11.js' in index
    assert index.index('./app.js') < index.index('./app-v11.js')

    for path in (APP_V11, STYLES_V11, LEARNING, INVENTORY, DELTA, GENERATOR):
        assert path.exists()
        assert path.stat().st_size > 0

    # v1.1 remains an additive layer over the reviewed v1 graph renderer.
    assert (ROUTE / "app-graph.js").exists()
    assert (ROUTE / "app.js").exists()


def test_learning_contract_is_evidence_bound_and_versioned():
    model = load_learning_model()
    assert model["fragment_version"] == "hub-optimus-project-intelligence.learning.v1.1"
    assert model["release"]["version"] == "1.1"
    assert model["release"]["status"] == "experimental"
    assert model["release"]["issue"] == 1912
    assert "opaque model training" in model["release"]["boundary"]

    assert model["baseline"]["semantic_model_commit"] == BASELINE_COMMIT
    assert model["baseline"]["v1_candidate_commit"] == V1_CANDIDATE
    assert model["baseline"]["repository"] == "Voxterrae/HUB_Optimus"
    assert model["artifacts"] == {
        "repository_inventory": "./system.inventory.json",
        "model_delta": "./system.delta.json",
        "generator": "tools/project_intelligence/repository_intelligence.py",
        "inventory_note": (
            "obsidian-HUB_Optimus/98_META/Deterministic Repository Inventory.md"
        ),
        "delta_note": "obsidian-HUB_Optimus/98_META/Model Delta and Drift.md",
    }

    snapshot = model["coverage"]["model_snapshot"]
    assert snapshot == {
        "components": 16,
        "interfaces": 7,
        "entities": 13,
        "relations": 25,
        "risks": 8,
        "confidence": "CONFIRMED",
        "source": [
            "site/obsidian-HUB_Optimus/system.json",
            "site/obsidian-HUB_Optimus/system.runtime.json",
        ],
    }

    assert model["coverage"]["repository_inventory"]["status"] == "active"
    assert model["coverage"]["incremental_delta"]["status"] == "experimental"
    assert model["coverage"]["live_external_state"] == {
        "status": "unknown",
        "confidence": "UNKNOWN",
        "description": (
            "Mutable settings, infrastructure and service state remain separate from "
            "repository learning and require direct inspection."
        ),
    }

    contract = model["evidence_contract"]
    assert set(contract["status_vocabulary"]) == ALLOWED_STATUSES
    assert set(contract["confidence_vocabulary"]) == ALLOWED_CONFIDENCE
    assert {
        "claim",
        "source",
        "baseline",
        "status",
        "confidence",
        "freshness",
        "review_state",
    } == set(contract["required_dimensions"])

    capabilities = model["capabilities"]
    assert len(capabilities) >= 6
    by_id = {item["id"]: item for item in capabilities}
    assert set(by_id) >= {
        "graph-node-search",
        "graph-impact-focus",
        "graph-viewport",
        "relation-evidence",
        "repository-domain-inventory",
        "incremental-model-delta",
    }
    assert by_id["repository-domain-inventory"]["status"] == "active"
    assert by_id["incremental-model-delta"]["status"] == "experimental"
    for item in capabilities:
        assert item["status"] in ALLOWED_STATUSES
        assert item["confidence"] in ALLOWED_CONFIDENCE
        assert item["evidence"]


def test_repository_inventory_and_delta_are_pinned_and_review_only():
    inventory = load_inventory()
    delta = load_delta()

    assert inventory["schema_version"] == (
        "hub-optimus-project-intelligence.inventory.v1.1"
    )
    assert delta["schema_version"] == "hub-optimus-project-intelligence.delta.v1.1"
    assert inventory["repository"]["name"] == "Voxterrae/HUB_Optimus"
    assert inventory["repository"]["semantic_baseline_commit"] == BASELINE_COMMIT
    assert len(inventory["repository"]["commit"]) == 40
    assert len(inventory["repository"]["tree"]) == 40
    assert delta["comparison"]["from_commit"] == BASELINE_COMMIT
    assert delta["comparison"]["to_commit"] == inventory["repository"]["commit"]
    assert delta["comparison"]["to_tree"] == inventory["repository"]["tree"]

    files = inventory["files"]
    file_paths = [item["path"] for item in files]
    assert len(file_paths) == len(set(file_paths))
    assert inventory["summary"]["tracked_files"] == len(files)
    assert inventory["summary"]["mapped_files"] > 0
    assert 0 <= inventory["summary"]["source_coverage_ratio"] <= 1
    assert inventory["summary"]["unresolved_model_sources"] == 0
    assert inventory["unresolved_model_sources"] == []
    assert "site/obsidian-HUB_Optimus/system.inventory.json" not in file_paths
    assert "site/obsidian-HUB_Optimus/system.delta.json" not in file_paths

    changes = delta["changes"]
    assert delta["summary"]["changed_paths"] == len(changes)
    assert len({(item["status"], item["path"]) for item in changes}) == len(changes)
    assert delta["review_boundary"]["automatic_fact_updates"] is False
    assert delta["review_boundary"]["human_review_required"] is True
    assert delta["review_boundary"]["live_external_state"] == "UNKNOWN"
    assert set(delta["impact"]) == {
        "direct_nodes",
        "upstream_nodes",
        "downstream_nodes",
    }

    generator = GENERATOR.read_text(encoding="utf-8")
    for contract in (
        "tracked_git_objects_only",
        "unmapped_architecture_candidates",
        "automatic_fact_updates",
        "human_review_required",
        "--check",
    ):
        assert contract in generator


def test_v11_graph_interaction_contracts():
    javascript = APP_V11.read_text(encoding="utf-8")
    styles = STYLES_V11.read_text(encoding="utf-8")

    for contract in (
        'const ADDON_MODEL_URL = "./system.learning.json"',
        'const INVENTORY_MODEL_URL = "./system.inventory.json"',
        'const DELTA_MODEL_URL = "./system.delta.json"',
        '"direct"',
        '"upstream"',
        '"downstream"',
        "bestSearchMatch",
        "reachable",
        "renderRepositoryPulse",
        "MutationObserver",
        'addEventListener("wheel"',
        'addEventListener("pointerdown"',
        'setAttribute("aria-live", "polite")',
        'setAttribute("tabindex", "0")',
        "prefers-reduced-motion",
    ):
        assert contract in javascript or contract in styles

    assert "innerHTML" not in javascript
    assert "eval(" not in javascript
    assert "new Function" not in javascript
    assert "textContent" in javascript
    assert "replaceChildren" in javascript
    assert "Promise.all" in javascript
    assert "Repository inventory and delta do not share" in javascript

    for selector in (
        ".graph-intelligence-toolbar",
        ".graph-node.v11-dimmed",
        ".graph-edge.v11-edge-focus",
        ".learning-capability-grid",
        ".repository-intelligence-panel",
        ".repository-metric-grid",
        ".repository-domain-chip",
        "@media (max-width: 760px)",
        "@media (prefers-reduced-motion: reduce)",
    ):
        assert selector in styles

    # Flex items with unbroken relation labels must be allowed to shrink on mobile.
    for selector in (
        ".graph-focus-status",
        ".graph-relation-inspector",
        ".graph-relation-chip",
    ):
        block = re.search(
            rf"{re.escape(selector)}\s*\{{(?P<body>[^}}]*)\}}",
            styles,
            re.DOTALL,
        )
        assert block, selector
        assert re.search(r"min-width\s*:\s*0\s*;", block.group("body")), selector


def test_v11_obsidian_notes_define_graph_and_learning_boundaries():
    notes = {
        "02_ARCHITECTURE/Graph Intelligence v1.1.md": (
            "# Graph Intelligence v1.1",
            "No inferred edge is created by the browser.",
        ),
        "98_META/Whole-System Learning.md": (
            "# Whole-System Learning",
            "does not mean autonomous truth adjudication",
            "generated candidates do not become canonical facts without review",
        ),
        "98_META/Repository Coverage.md": (
            "# Repository Coverage",
            "source coverage is not semantic completeness",
        ),
        "98_META/Deterministic Repository Inventory.md": (
            "# Deterministic Repository Inventory",
            "does not become self-referential",
        ),
        "98_META/Model Delta and Drift.md": (
            "# Model Delta and Drift",
            "not proof of a runtime regression",
        ),
    }
    for relative, phrases in notes.items():
        path = VAULT / relative
        assert path.exists(), relative
        content = path.read_text(encoding="utf-8")
        assert content.startswith("---\n")
        assert BASELINE_COMMIT in content
        assert V1_CANDIDATE in content
        for phrase in phrases:
            assert phrase in content


def test_v11_learning_keeps_automatic_fact_mutation_prohibited():
    model = load_learning_model()
    whole_system = (VAULT / "98_META" / "Whole-System Learning.md").read_text(
        encoding="utf-8"
    )
    delta_note = (VAULT / "98_META" / "Model Delta and Drift.md").read_text(
        encoding="utf-8"
    )

    assert model["coverage"]["repository_inventory"]["status"] == "active"
    assert model["coverage"]["incremental_delta"]["status"] == "experimental"
    assert "Planned capabilities remain labelled `planned`" in whole_system
    assert "do not become canonical facts without review" in whole_system
    assert "without automatically changing canonical system facts" in delta_note
