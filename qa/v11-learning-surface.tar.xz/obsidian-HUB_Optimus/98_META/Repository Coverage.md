---
type: meta
status: partial
layer: project-intelligence
criticality: high
source:
  - site/obsidian-HUB_Optimus/system.json
  - site/obsidian-HUB_Optimus/system.runtime.json
  - site/obsidian-HUB_Optimus/system.learning.json
  - site/obsidian-HUB_Optimus/system.inventory.json
  - site/obsidian-HUB_Optimus/system.delta.json
  - tools/project_intelligence/repository_intelligence.py
tags:
  - coverage
  - source-map
  - drift
baseline_commit: 30e985226347b4bc59b0e187b96633a09647ca42
v1_candidate_commit: 9c7b5d81b2cf85d349b1ca141d559a75067a9b14
---

# Repository Coverage

## Current confirmed semantic coverage

For baseline commit `30e985226347b4bc59b0e187b96633a09647ca42`, the reviewed model contains:

| Model object | Count |
|---|---:|
| Components | 16 |
| Interfaces | 7 |
| Entities | 13 |
| Relations | 25 |
| Risks | 8 |

These counts come from the synchronized v1 JSON model deployed from candidate `9c7b5d81b2cf85d349b1ca141d559a75067a9b14`.

## Deterministic repository measurement

v1.1 now generates `system.inventory.json` from a pinned Git commit and tree. It records:

- tracked file paths, object IDs, modes and byte sizes;
- deterministic repository-domain labels;
- exact and directory-prefix model-source rules;
- mapped and unmapped files;
- architecture-relevant mapping candidates;
- unresolved model-source references;
- the analyzed commit, tree and generation boundary.

The current numbers must be read from the artifact itself or the v1.1 browser panel; they are intentionally not copied into this note because each regeneration is commit-specific. See [[Deterministic Repository Inventory]].

## What this proves

The inventory proves which Git objects existed at its pinned commit and how the declared source rules matched them. The semantic model covers the components, interfaces, entities, runtime flows, deployment boundaries and risks explicitly represented by the reviewed snapshot. [[Source Map]] connects those concepts to repository paths.

## What this does not prove

The inventory does not prove that every tracked file is architecturally significant, that every significant concept is modeled, or that mutable infrastructure is live. Domain and architecture-candidate labels can be `INFERRED`; source coverage is not semantic completeness.

It also does not prove mutable external state such as repository settings, Pages runtime, EC2, DNS, TLS or Nginx.

## Coverage dimensions

1. **Semantic coverage** — which system concepts are represented.
2. **Source coverage** — which repository paths support those concepts.
3. **Test coverage map** — which tests and workflows protect each concept.
4. **Change coverage** — which evidence paths changed between pinned commits.
5. **Impact coverage** — which modeled nodes are directly, upstream or downstream related to changed evidence.
6. **External-state coverage** — which mutable objects were directly inspected.

Each dimension is reported separately. A high value in one dimension cannot substitute for evidence in another.

## Active quality gates

- every model source path must resolve at the pinned analyzed commit;
- every relation must identify supported endpoints;
- every published view remains closed over its nodes and relations;
- unmapped repository candidates are listed rather than ignored;
- baseline drift is explicit;
- generated artifacts support deterministic `--check` validation;
- external state is never inferred from source presence.

## Related

- [[Whole-System Learning]]
- [[Deterministic Repository Inventory]]
- [[Model Delta and Drift]]
- [[Evidence Index]]
- [[Testing Strategy]]
- [[Risk Register]]
- [[Update Protocol]]
