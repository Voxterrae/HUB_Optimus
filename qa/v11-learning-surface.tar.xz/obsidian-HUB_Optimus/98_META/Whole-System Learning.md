---
type: meta
status: experimental
layer: project-intelligence
criticality: high
source:
  - site/obsidian-HUB_Optimus/system.learning.json
  - site/obsidian-HUB_Optimus/system.inventory.json
  - site/obsidian-HUB_Optimus/system.delta.json
  - tools/project_intelligence/repository_intelligence.py
  - site/obsidian-HUB_Optimus/app-v11.js
tags:
  - evidence
  - learning
  - provenance
  - maintenance
baseline_commit: 30e985226347b4bc59b0e187b96633a09647ca42
v1_candidate_commit: 9c7b5d81b2cf85d349b1ca141d559a75067a9b14
---

# Whole-System Learning

## Definition

“Learning” in HUB_Optimus Project Intelligence means a repeatable process that converts repository observations into reviewed, source-bound model facts. It does not mean autonomous truth adjudication, prediction or opaque training over repository content.

The semantic baseline remains commit `30e985226347b4bc59b0e187b96633a09647ca42`; the exact reviewed v1 candidate is `9c7b5d81b2cf85d349b1ca141d559a75067a9b14`.

## Required dimensions

Every learned claim must retain:

1. the claim itself;
2. repository source or direct external observation;
3. analyzed commit and tree;
4. implementation status;
5. epistemic confidence;
6. freshness;
7. review state.

The permitted status and confidence vocabulary remains defined by [[Status Definitions]].

## Executable learning pipeline

```text
Pinned repository commit + tree
        ↓
Deterministic tracked-object inventory
        ↓
Domain and source-rule mapping
        ↓
Unresolved / unmodelled candidates
        ↓
Baseline-to-commit delta
        ↓
Direct / upstream / downstream impact
        ↓
Human review
        ↓
Affected facts, notes, views and tests
```

The generator is `tools/project_intelligence/repository_intelligence.py`. Its reviewable outputs are:

- `site/obsidian-HUB_Optimus/system.inventory.json` — [[Deterministic Repository Inventory]];
- `site/obsidian-HUB_Optimus/system.delta.json` — [[Model Delta and Drift]].

## v1.1 implemented or experimental capabilities

- graph node search;
- direct, upstream and downstream impact focus;
- zoom, pan and fit controls;
- relation-evidence inspection;
- deterministic Git-object inventory;
- repository-domain classification;
- explicit model-source coverage measurement;
- unresolved-source and unmodelled-surface reporting;
- baseline-to-commit changed-path delta;
- relation-derived impact candidates;
- browser display of repository coverage and change metrics.

## Still planned

- source → component → interface → entity → test → deployment coverage as a complete typed graph;
- automatic preparation of affected-note patches;
- historical multi-baseline comparison;
- human-approved regeneration of semantic facts and views;
- direct inspection adapters for mutable external systems.

Planned capabilities remain labelled `planned`; generated candidates do not become canonical facts without review.

## Boundaries

- Code presence does not prove live deployment.
- A document does not override executable source, active configuration, schemas or tests in their own domains.
- A draft, local learning candidate or intake record is not canonical evidence.
- An inference remains `INFERRED` until evidence changes.
- Path classification is not equivalent to semantic completeness.
- A changed file is an impact candidate, not proof that the architectural claim changed.
- Mutable repository settings, DNS, TLS, EC2 and service state remain `UNKNOWN` until directly inspected.

## Maintenance

Use [[Update Protocol]] together with [[Deterministic Repository Inventory]] and [[Model Delta and Drift]]. Pin the comparison, regenerate deterministically, review candidates, and then update only the facts whose evidence set genuinely changed.

## Related

- [[Repository Coverage]]
- [[Graph Intelligence v1.1]]
- [[Deterministic Repository Inventory]]
- [[Model Delta and Drift]]
- [[Documentation Standard]]
- [[Evidence Index]]
- [[Current State]]
