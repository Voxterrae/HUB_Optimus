---
type: meta
status: experimental
layer: project-intelligence
criticality: high
source:
  - tools/project_intelligence/repository_intelligence.py
  - site/obsidian-HUB_Optimus/system.delta.json
  - site/obsidian-HUB_Optimus/system.inventory.json
  - site/obsidian-HUB_Optimus/system.json
  - site/obsidian-HUB_Optimus/system.runtime.json
tags:
  - delta
  - drift
  - impact
  - review
baseline_commit: 30e985226347b4bc59b0e187b96633a09647ca42
v1_candidate_commit: 9c7b5d81b2cf85d349b1ca141d559a75067a9b14
---

# Model Delta and Drift

## Purpose

`system.delta.json` compares the semantic baseline with one pinned analyzed repository commit. It identifies changed evidence and prepares review candidates without automatically changing canonical system facts.

## Delta contents

- baseline and analyzed commit/tree identities;
- added, modified, deleted, renamed or copied paths;
- changed repository domains;
- model objects supported by changed source paths;
- direct modeled nodes affected by changed evidence;
- upstream and downstream relation closure;
- changed architecture candidates without model mappings;
- freshness, source and coverage drift candidates;
- a mandatory human-review boundary.

## Impact semantics

Impact is derived only from existing typed relations in `system.json` and `system.runtime.json`:

- **direct** — a modeled node has changed source evidence;
- **upstream** — a node can reach a directly affected node through directed relations;
- **downstream** — a node is reachable from a directly affected node.

This is structural impact, not proof of a runtime regression.

## Drift semantics

A drift candidate can indicate:

- the semantic baseline differs from the analyzed commit;
- a declared source no longer resolves;
- architecture-relevant changed paths are not mapped;
- reviewed facts may require freshness assessment.

Candidates preserve `status`, `confidence`, evidence and `review_state`. They do not silently overwrite prior documentation.

## Review gate

Before updating the model:

1. inspect the changed source evidence;
2. decide whether the architectural claim actually changed;
3. preserve historical discrepancy where useful;
4. update only affected JSON facts and Obsidian notes;
5. run structural and browser validation;
6. keep mutable external state `UNKNOWN` unless directly inspected.

## Related

- [[Deterministic Repository Inventory]]
- [[Whole-System Learning]]
- [[Repository Coverage]]
- [[Dependency Graph]]
- [[Update Protocol]]
- [[Risk Register]]
