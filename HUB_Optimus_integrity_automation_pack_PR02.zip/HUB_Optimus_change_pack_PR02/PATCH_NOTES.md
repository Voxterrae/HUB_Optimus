# HUB_Optimus - Integrity Automation Pack (PR-02)

## What this pack does

Adds a CI guard to prevent drift when directories are duplicated for docs hosting.

- Adds `tools/check_mirror.py`
  - Compares SRC and DST directories byte-for-byte.
  - Fails CI if there are missing, extra, or changed files.
  - Skips if DST does not exist (configurable).

- Adds `.github/workflows/mirror-check.yml`
  - Runs on push to `main` and on pull requests.
  - Default pair: `v1_core:docs/v1_core`.

## How to apply

Copy the folders into your repo root:

- tools/check_mirror.py
- .github/workflows/mirror-check.yml

## Why this matters

You currently keep canonical kernel content under `v1_core/`, and a mirror under `docs/v1_core/`
(for Pages and doc routing). That duplication is a governance risk: drift can happen silently.

This PR turns drift into a loud, immediate failure.
