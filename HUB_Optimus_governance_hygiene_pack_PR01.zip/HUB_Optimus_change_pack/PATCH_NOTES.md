# HUB_Optimus - Governance & Hygiene Pack (PR-01)

## What this pack does

Adds missing governance basics and reduces repo noise:

- Adds `LICENSE` (conservative: "no license granted"; points to IP_NOTICE)
- Adds `SECURITY.md` (responsible disclosure workflow)
- Adds `mkdocs.yml` (optional; to build a docs site with MkDocs)
- Provides `.gitignore.additions` with recommended ignore rules (do not blindly overwrite)

## How to apply (manual)

1) Copy these files into the repo root:
- LICENSE
- SECURITY.md
- mkdocs.yml (optional)

2) Merge ignore rules:
- Append the content of `.gitignore.additions` to your existing `.gitignore`.

3) Clean up artifacts (recommended):
- Remove `HUB_Optimus_GitHub_Release.zip` from the repository history and use GitHub Releases.
- Ensure `site/` and `lychee*.txt` are not committed.

## Next moves (PR-02)

- Decide the licensing posture (keep restricted vs docs under CC BY-SA vs full open-source)
- If MkDocs is adopted: add a GitHub Action to build + deploy to GitHub Pages (`gh-pages`)
- Reduce duplication between `v1_core/` and `docs/v1_core/` (single source of truth)
